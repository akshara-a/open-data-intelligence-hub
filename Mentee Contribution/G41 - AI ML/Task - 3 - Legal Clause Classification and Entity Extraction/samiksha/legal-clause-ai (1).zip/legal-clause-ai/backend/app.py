"""Flask API + static frontend.   python app.py   ->  http://localhost:5000"""
import os, io, csv, json
from flask import Flask, jsonify, request, send_from_directory
from nlp.pipeline import Pipeline

ROOT = os.path.dirname(os.path.abspath(__file__)); FRONT = os.path.join(ROOT, "..", "frontend"); SAMPLES = os.path.join(ROOT, "..", "data", "samples")
app = Flask(__name__, static_folder=FRONT, static_url_path=""); app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024
pipe = Pipeline(os.path.join(ROOT, "models")); MAXC = 400_000

def read_upload(f):
    raw = f.read().decode("utf-8", errors="replace")
    if f.filename.lower().endswith(".csv"):
        rows = list(csv.reader(io.StringIO(raw)))
        if not rows: return ""
        head = [h.lower() for h in rows[0]]; col = next((head.index(c) for c in ("text", "content", "contract", "clause") if c in head), None)
        body = rows[1:] if col is not None else rows
        return "\n\n".join(r[col if col is not None else max(range(len(r)), key=lambda i: len(r[i]))] for r in body if r)
    return raw

@app.get("/")
def index(): return send_from_directory(FRONT, "index.html")

@app.get("/api/health")
def health(): return jsonify(status="ok", labels=pipe.cfg["labels"], ner_tau=pipe.cfg["ner_tau"], clause_tau=pipe.cfg["clause_tau"])

@app.post("/api/analyze")
def analyze():
    if request.files.get("file"): text = read_upload(request.files["file"])
    else: text = (request.get_json(silent=True) or {}).get("text", "")
    j = request.get_json(silent=True) or {}; g = request.form if request.files else j
    if not text.strip(): return jsonify(error="No text provided"), 400
    if len(text) > MAXC: return jsonify(error=f"Text too long (max {MAXC} characters)"), 413
    try:
        res = pipe.analyze(text, float(g.get("ocr_noise", 0) or 0), float(g["ner_tau"]) if g.get("ner_tau") else None, float(g["clause_tau"]) if g.get("clause_tau") else None)
    except Exception as e: return jsonify(error=str(e)), 500
    return jsonify(res)

@app.get("/api/metrics")
def metrics(): return send_from_directory(os.path.join(ROOT, "models"), "metrics.json")

@app.get("/api/samples")
def samples():
    return jsonify([{"name": n[:-4].replace("_", " "), "text": open(os.path.join(SAMPLES, n), encoding="utf-8").read()} for n in sorted(os.listdir(SAMPLES)) if n.endswith(".txt")])

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=False)
