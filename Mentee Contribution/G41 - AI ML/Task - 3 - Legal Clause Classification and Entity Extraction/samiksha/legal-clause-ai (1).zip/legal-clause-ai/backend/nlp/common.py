"""Shared deterministic NLP utilities: tokenisation, segmentation, silver labels, OCR noise, BPE, embeddings."""
import re, random
import numpy as np

# ---------------------------------------------------------------- tokenisation (offset preserving)
TOKEN_RE = re.compile(r"\$|[A-Za-z]+(?:['’\-][A-Za-z]+)*|\d+(?:[.,]\d+)*|[^\sA-Za-z\d]")

def tokenize(text):
    """Return [(start, end, string)] - offsets always index the ORIGINAL text."""
    return [(m.start(), m.end(), m.group()) for m in TOKEN_RE.finditer(text)]

def norm(tok):
    return re.sub(r"\d", "0", tok.lower())

def shape(tok):
    s = re.sub(r"[A-Z]+", "A", tok); s = re.sub(r"[a-z]+", "a", s); return re.sub(r"\d+", "0", s)

# ---------------------------------------------------------------- clause segmentation
_SENT = re.compile(r"(?<=[.;:])\s+(?=[A-Z(\"“0-9])|\n\s*\n")

def segment(text, min_len=60, max_len=900):
    """Split into clause-sized units. Returns [(start, end)] over the original text."""
    cuts, last = [], 0
    for m in _SENT.finditer(text):
        cuts.append((last, m.start())); last = m.end()
    cuts.append((last, len(text)))
    units, cur = [], None
    for s, e in cuts:
        if e - s < 3: continue
        if cur is None: cur = [s, e]
        elif (cur[1] - cur[0]) < min_len and (e - cur[0]) <= max_len: cur[1] = e
        else: units.append(tuple(cur)); cur = [s, e]
    if cur: units.append(tuple(cur))
    return units

# ---------------------------------------------------------------- silver / gold entity patterns
MONTH = r"(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|June?|July?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\.?"
DATE_RES = [re.compile(p, re.I) for p in [
    r"\b\d{1,2}(?:st|nd|rd|th)?\s+day\s+of\s+" + MONTH + r",?\s+\d{4}",
    r"\b" + MONTH + r"\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4}",
    r"\b\d{1,2}(?:st|nd|rd|th)?\s+" + MONTH + r",?\s+\d{4}",
    r"\b" + MONTH + r",?\s+\d{4}",
    r"\b\d{1,2}/\d{1,2}/\d{2,4}\b", r"\b\d{4}-\d{2}-\d{2}\b"]]
MONEY_RES = [re.compile(p) for p in [
    r"(?:US|U\.S\.)?\s?\$\s?\d[\d,]*(?:\.\d+)?(?:\s*(?:million|billion|thousand|MM))?",
    r"\b\d[\d,]*(?:\.\d+)?\s*(?:U\.?S\.?\s*)?(?:dollars|Dollars|DOLLARS)\b"]]
ORG_SUFFIX = r"(?:Inc|Incorporated|INC|INCORPORATED|Corp|Corporation|CORP|CORPORATION|LLC|L\.L\.C|Ltd|Limited|LTD|LIMITED|Co|Company|COMPANY|LP|L\.P|LLP|plc|PLC|GmbH|AG|S\.A|N\.V|B\.V|Holdings|HOLDINGS)"
ORG_RE = re.compile(r"(?:(?:[A-Z][\w&'’\-]*|&)[\s,]+){0,6}(?:[A-Z][\w&'’\-]*)(?:,?\s+" + ORG_SUFFIX + r")\b\.?")
_ORG_STOP = set("the this by and between with of for among party parties agreement said to from in on at as its each any such whereas now that is are or a an if upon under pursuant dated effective entered into made".split())

def _trim_org(txt, start):
    while True:
        m = re.match(r"\s*([A-Za-z&'’\-]+|[^\w\s])[\s,]*", txt)
        if not m: break
        w = m.group(1)
        if w.lower() in _ORG_STOP or not (w[0].isupper() or w == "&") or not re.match(r"\w", w):
            txt, start = txt[m.end():], start + m.end()
        else: break
    return start, txt.rstrip(" ,")

def silver_char_labels(text, parties=()):
    """Char-level labels (None / 'ORG' / 'DATE' / 'MONEY'). Gold CUAD party names are used when given."""
    lab = [None] * len(text)
    def put(s, e, l):
        if all(x is None for x in lab[s:e]):
            for i in range(s, e): lab[i] = l
    for r in MONEY_RES:
        for m in r.finditer(text): put(m.start() + (len(m.group()) - len(m.group().lstrip())), m.end(), "MONEY")
    for r in DATE_RES:
        for m in r.finditer(text): put(m.start(), m.end(), "DATE")
    for m in ORG_RE.finditer(text):
        s, t = _trim_org(m.group(), m.start())
        if len(t) >= 4 and re.search(r"[A-Za-z]{2}", t): put(s, s + len(t), "ORG")
    for p in parties:
        p = p.strip()
        if len(p) >= 5 and re.search(r"[A-Z]", p) and (re.search(ORG_SUFFIX + r"\b", p) or len(p.split()) >= 2):
            for m in re.finditer(re.escape(p), text): put(m.start(), m.end(), "ORG")
    return lab

def bio_from_char_labels(tokens, lab):
    out, prev = [], None
    for s, e, _ in tokens:
        l = lab[s] if s < len(lab) else None
        out.append("O" if l is None else (("I-" if l == prev else "B-") + l)); prev = l
    return out

def bio_to_spans(bio):
    """BIO -> [(first_tok, last_tok_exclusive, label)]"""
    spans, cur = [], None
    for i, t in enumerate(bio + ["O"]):
        if cur and (t == "O" or t.startswith("B-") or t[2:] != cur[2]):
            spans.append((cur[0], i, cur[2])); cur = None
        if t != "O" and cur is None: cur = (i, None, t[2:])
    return spans

# ---------------------------------------------------------------- OCR noise (keeps per-char labels aligned)
_SUB = {"O": "0", "0": "O", "l": "1", "1": "l", "I": "l", "S": "5", "5": "S", "B": "8", "e": "c", "m": "rn"}
def add_ocr_noise(text, lab, p=0.03, rng=None):
    rng = rng or random.Random()
    out, olab, i = [], [], 0
    while i < len(text):
        c, l, r = text[i], lab[i], rng.random()
        if c in ",.;:()\"'" and r < p * 6: i += 1; continue
        if c == " " and r < p * 1.5: i += 1; continue
        if c.isalnum() and r < p * 0.35: i += 1; continue
        if c.isalnum() and r < p * 0.8 and c in _SUB:
            for ch in _SUB[c]: out.append(ch); olab.append(l)
            i += 1; continue
        if c.isalpha() and r < p * 1.1: out += [c, " "]; olab += [l, l if (l and i + 1 < len(text) and lab[i+1] == l) else None]; i += 1; continue
        if c.isalpha() and r < p * 1.4 and i + 1 < len(text) and text[i+1].isalpha():
            out += [text[i+1], c]; olab += [lab[i+1], l]; i += 2; continue
        out.append(c); olab.append(l); i += 1
    return "".join(out), olab

# ---------------------------------------------------------------- BPE + embeddings
class Subword:
    def __init__(self, path=None):
        from tokenizers import Tokenizer
        self.tk = Tokenizer.from_file(path) if path else None; self.cache = {}
    @staticmethod
    def train(words_iter, path, vocab=6000):
        from tokenizers import Tokenizer, models, trainers, pre_tokenizers
        tk = Tokenizer(models.BPE(unk_token="[UNK]")); tk.pre_tokenizer = pre_tokenizers.Whitespace()
        tk.train_from_iterator(words_iter, trainers.BpeTrainer(vocab_size=vocab, min_frequency=3, special_tokens=["[UNK]"]))
        tk.save(path)
    def pieces(self, w):
        r = self.cache.get(w)
        if r is None: r = self.cache[w] = self.tk.encode(w).tokens or ["[UNK]"]
        return r

class Embedder:
    """Dense Word2Vec vectors over BPE pieces; word vector = mean of its piece vectors (OOV-safe)."""
    def __init__(self, sw, path=None):
        from gensim.models import KeyedVectors
        self.sw = sw; self.kv = KeyedVectors.load(path) if path else None
        self.dim = self.kv.vector_size if self.kv else 0; self.cache = {}
    def vec(self, w):
        v = self.cache.get(w)
        if v is None:
            ps = [p for p in self.sw.pieces(w) if p in self.kv.key_to_index]
            v = self.cache[w] = np.mean([self.kv[p] for p in ps], 0) if ps else np.zeros(self.dim, "float32")
        return v
    def text_vec(self, toks):
        if not toks: return np.zeros(self.dim, "float32")
        return np.mean([self.vec(t) for t in toks], 0)
