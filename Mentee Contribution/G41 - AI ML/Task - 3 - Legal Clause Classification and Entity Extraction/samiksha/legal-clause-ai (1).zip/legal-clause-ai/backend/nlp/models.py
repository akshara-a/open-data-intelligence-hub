"""CRF feature extraction (BPE + embedding features) and clause-feature construction. Used by train.py and the API."""
import re, numpy as np
from .common import norm, shape

SUFFIXES = {"inc", "corp", "corporation", "llc", "ltd", "limited", "co", "company", "lp", "llp", "plc", "gmbh", "ag", "holdings", "incorporated"}
MONTHS = {"january","february","march","april","may","june","july","august","september","october","november","december","jan","feb","mar","apr","jun","jul","aug","sep","sept","oct","nov","dec"}

def tok_feats(w, emb):
    n = norm(w); ps = emb.sw.pieces(n)
    f = {"w": n, "p3": n[:3], "s3": n[-3:], "sh": shape(w), "up": w.isupper(), "ti": w[:1].isupper(),
         "dg": any(c.isdigit() for c in w), "p0": ps[0], "pl": ps[-1], "np": min(len(ps), 4),
         "suf": n.rstrip(".") in SUFFIXES, "mon": n.rstrip(".") in MONTHS or n[:3] in MONTHS, "cur": w == "$" or n in ("dollars", "million")}
    for i, x in enumerate(emb.vec(n)): f[f"e{i}"] = float(x)
    return f

def sent_feats(words, emb):
    base = [tok_feats(w, emb) for w in words]; out = []
    for i, f in enumerate(base):
        d = dict(f); d["bias"] = 1.0
        for off in (-2, -1, 1, 2):
            j = i + off
            if 0 <= j < len(base):
                g = base[j]
                for k in ("w", "sh", "ti", "suf", "mon", "cur", "dg"): d[f"{off}:{k}"] = g[k]
            else: d["BOS" if off < 0 else "EOS"] = True
        out.append(d)
    return out

def clause_vector_inputs(text, tokens, emb):
    """Normalised BPE-piece string (for TF-IDF) and mean embedding (dense) for a clause."""
    words = [norm(t) for _, _, t in tokens if re.match(r"\w", t)]
    pieces = [p for w in words for p in emb.sw.pieces(w)]
    return " ".join(pieces), emb.text_vec(words)
