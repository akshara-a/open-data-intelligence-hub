"""Inference pipeline: OCR-tolerant tokenisation -> BPE+W2V -> CRF NER + clause classifier -> span-exact JSON."""
import json, os, pickle, random
import numpy as np
from scipy.sparse import hstack, csr_matrix
from .common import tokenize, segment, bio_to_spans, Subword, Embedder, add_ocr_noise
from .models import sent_feats, clause_vector_inputs, SUFFIXES

class Pipeline:
    def __init__(self, d):
        self.cfg = json.load(open(f"{d}/config.json"))
        self.emb = Embedder(Subword(f"{d}/bpe.json"), f"{d}/w2v.kv")
        self.crf = pickle.load(open(f"{d}/crf.pkl", "rb"))
        c = pickle.load(open(f"{d}/clause.pkl", "rb")); self.tf, self.clf = c["tfidf"], c["clf"]

    def entities(self, text, off=0, tau=None):
        tau = self.cfg["ner_tau"] if tau is None else tau
        tk = tokenize(text)
        if not tk: return []
        marg = self.crf.predict_marginals_single(sent_feats([t for _, _, t in tk], self.emb))
        bio = [max(m, key=m.get) for m in marg]; out = []
        for a, b, lab in bio_to_spans(bio):
            conf = min(marg[k][bio[k]] for k in range(a, b))
            if conf < tau: continue                       # precision-first: drop uncertain spans
            parts, st = [], a                      # split "X Inc and Y LLC" into two ORG spans
            if lab == "ORG":
                for k in range(a + 1, b - 1):
                    if tk[k][2].lower() in ("and", "&") and tk[k - 1][2].lower().rstrip(".") in SUFFIXES: parts.append((st, k)); st = k + 1
            parts.append((st, b))
            for x, y in parts:
                s, e = tk[x][0], tk[y - 1][1]
                out.append({"start": off + s, "end": off + e, "text": text[s:e], "label": lab, "confidence": round(float(conf), 4)})
        return out

    def analyze(self, text, ocr_noise=0.0, ner_tau=None, clause_tau=None, seed=1):
        ctau = self.cfg["clause_tau"] if clause_tau is None else clause_tau
        noisy = False
        if ocr_noise > 0:                                  # demo only: simulate a worse scan; spans index the noisy text
            text, _ = add_ocr_noise(text, [None] * len(text), ocr_noise, random.Random(seed)); noisy = True
        ents = []
        for s, e in segment(text, 30, 400): ents += self.entities(text[s:e], s, ner_tau)
        units = segment(text); rows = []
        for s, e in units:
            seg = text[s:e]; rows.append(clause_vector_inputs(seg, tokenize(seg), self.emb))
        clauses = []
        if rows:
            X = hstack([self.tf.transform([r[0] for r in rows]), csr_matrix(np.array([r[1] for r in rows]) * 2)]).tocsr()
            P = self.clf.predict_proba(X); cls = self.clf.classes_
            for (s, e), p in zip(units, P):
                j = int(p.argmax())
                if cls[j] == "Other" or p[j] < ctau: continue
                top = sorted(zip(cls, p), key=lambda x: -x[1])[:3]
                clauses.append({"start": s, "end": e, "text": text[s:e], "label": str(cls[j]), "confidence": round(float(p[j]), 4),
                    "alternatives": [{"label": str(c), "probability": round(float(v), 4)} for c, v in top],
                    "entities": [x for x in ents if x["start"] >= s and x["end"] <= e]})
        for x in ents + clauses: assert text[x["start"]:x["end"]] == x["text"]   # zero-hallucination guard
        return {"text": text, "ocr_noise_applied": noisy, "length": len(text), "entities": ents, "clauses": clauses,
                "summary": {"entities": len(ents), "clauses": len(clauses),
                            "by_entity": {l: sum(x["label"] == l for x in ents) for l in ("ORG", "DATE", "MONEY")},
                            "by_clause": {l: sum(c["label"] == l for c in clauses) for l in sorted({c["label"] for c in clauses})}}}
