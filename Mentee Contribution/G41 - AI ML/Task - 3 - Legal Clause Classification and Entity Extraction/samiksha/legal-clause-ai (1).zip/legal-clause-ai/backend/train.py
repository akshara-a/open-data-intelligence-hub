"""Train the full pipeline on CUAD:  python train.py --cuad ../data/CUAD_v1/CUAD_v1.json
Stages: BPE tokenizer -> Word2Vec embeddings -> CRF NER (ORG/DATE/MONEY) -> clause classifier."""
import json, random, argparse, time, os, re, pickle
import numpy as np
from nlp.common import *
from nlp.models import sent_feats, clause_vector_inputs

ap = argparse.ArgumentParser(); ap.add_argument("--cuad", required=True); ap.add_argument("--ner-sents", type=int, default=9000)
args = ap.parse_args(); rng = random.Random(7); OUT = "models"; os.makedirs(OUT, exist_ok=True); t0 = time.time()

# --- clause label space. CUAD has no explicit Indemnification / Force Majeure question, so those two are weakly
# --- labelled by keyword triggers (documented in README); the rest come from gold CUAD annotations.
CUAD2LABEL = {"Cap On Liability": "Limitation of Liability", "Uncapped Liability": "Limitation of Liability",
 "Liquidated Damages": "Liquidated Damages", "Insurance": "Insurance", "Warranty Duration": "Warranty",
 "Termination For Convenience": "Termination for Convenience", "Governing Law": "Governing Law",
 "Anti-Assignment": "Anti-Assignment", "Change Of Control": "Change of Control", "Non-Compete": "Non-Compete",
 "Exclusivity": "Exclusivity", "Audit Rights": "Audit Rights", "Covenant Not To Sue": "Covenant Not to Sue"}
KW = {"Indemnification": re.compile(r"\b(indemnif\w*|hold\s+harmless)\b", re.I), "Force Majeure": re.compile(r"force\s+majeure|acts?\s+of\s+god", re.I)}
RARE = ["Force Majeure","Indemnification","Change of Control","Liquidated Damages","Covenant Not to Sue","Audit Rights","Non-Compete","Limitation of Liability","Insurance","Warranty","Exclusivity","Anti-Assignment","Termination for Convenience","Governing Law"]

data = json.load(open(args.cuad))["data"]; docs = []
for d in data:
    p = d["paragraphs"][0]; ans = {}
    for q in p["qas"]:
        ans[q["id"].split("__")[1]] = [(a["answer_start"], a["answer_start"] + len(a["text"]), a["text"]) for a in q["answers"]]
    docs.append((p["context"], ans))
idx = list(range(len(docs))); rng.shuffle(idx); cut = int(.8 * len(idx)); train_i, test_i = idx[:cut], idx[cut:]
print(len(docs), "contracts;", len(train_i), "train /", len(test_i), "test")

def unit_label(text, s, e, ans):
    seg = text[s:e]; found = set()
    for k, lab in CUAD2LABEL.items():
        for a, b, _ in ans.get(k, []):
            ov = min(e, b) - max(s, a)
            if ov > 0 and (ov >= .5 * (e - s) or ov >= .5 * (b - a)): found.add(lab)
    for lab, rx in KW.items():
        if rx.search(seg): found.add(lab)
    for lab in RARE:
        if lab in found: return lab
    return "Other"

# --- 1. BPE tokenizer (trained on normalised words)
def words(text): return [norm(t) for _, _, t in tokenize(text) if re.match(r"\w", t)]
Subword.train((" ".join(words(docs[i][0])) for i in train_i), f"{OUT}/bpe.json", 6000); sw = Subword(f"{OUT}/bpe.json")
print("BPE trained", round(time.time() - t0))

# --- 2. Word2Vec over BPE pieces (clean + noisy sentences => OOV/OCR robust vectors)
from gensim.models import Word2Vec
sents = []
for i in train_i:
    text, ans = docs[i]
    for (s, e) in segment(text)[:: 2]:
        w = words(text[s:e]); sents.append([p for x in w for p in sw.pieces(x)])
        nt, _ = add_ocr_noise(text[s:e], [None] * (e - s), .04, rng); w = words(nt); sents.append([p for x in w for p in sw.pieces(x)])
w2v = Word2Vec(sents, vector_size=24, window=5, min_count=2, workers=1, epochs=4, seed=7); w2v.wv.save(f"{OUT}/w2v.kv")
emb = Embedder(sw, f"{OUT}/w2v.kv"); print("W2V trained", len(w2v.wv), round(time.time() - t0))

# --- 3. NER data: sentence windows (all with entities + a share of negatives), clean + noisy
def ner_examples(ids, n_max, noise):
    ex = []
    for i in ids:
        text, ans = docs[i]; parties = [t for _, _, t in ans.get("Parties", [])]
        lab = silver_char_labels(text, parties)
        for (s, e) in segment(text, 30, 400):
            sl = lab[s:e]; seg = text[s:e]
            if any(sl) or rng.random() < .12:
                if noise: seg, sl = add_ocr_noise(seg, sl, rng.choice([.01, .03, .05, .08]), rng)
                tk = tokenize(seg)
                if 2 <= len(tk) <= 120: ex.append((seg, tk, bio_from_char_labels(tk, sl)))
    rng.shuffle(ex); return ex[:n_max]
tr = ner_examples(train_i, args.ner_sents, False)[: args.ner_sents // 2] + ner_examples(train_i, args.ner_sents, True)[: args.ner_sents // 2]
rng.shuffle(tr)
import sklearn_crfsuite
crf = sklearn_crfsuite.CRF(algorithm="lbfgs", c1=.05, c2=.05, max_iterations=90, all_possible_transitions=True)
crf.fit([sent_feats([t for _, _, t in tk], emb) for _, tk, _ in tr], [b for _, _, b in tr]); pickle.dump(crf, open(f"{OUT}/crf.pkl", "wb"))
print("CRF trained", len(tr), "sentences", round(time.time() - t0))

# --- NER evaluation at several noise levels, with probability threshold sweep
def predict_spans(text, tau):
    tk = tokenize(text); 
    if not tk: return tk, set()
    X = sent_feats([t for _, _, t in tk], emb); marg = crf.predict_marginals_single(X)
    bio = [max(m, key=m.get) for m in marg]; sp = set()
    for a, b, l in bio_to_spans(bio):
        conf = min(max(marg[j].get(bio[j], 0) for j in [k]) for k in range(a, b))
        if conf >= tau: sp.add((tk[a][0], tk[b - 1][1], l))
    return tk, sp
def gold_spans(text, lab):
    tk = tokenize(text); return {(tk[a][0], tk[b - 1][1], l) for a, b, l in bio_to_spans(bio_from_char_labels(tk, lab))}
test_docs = test_i[:40]; ner_metrics = {}
for p in [0, .02, .05, .08]:
    for tau in [.5, .7, .8, .85, .9]:
        tp = fp = fn = 0; per = {}; r2 = random.Random(1)
        for i in test_docs:
            text, ans = docs[i]; lab = silver_char_labels(text, [t for _, _, t in ans.get("Parties", [])])
            for (s, e) in segment(text, 30, 400)[::6]:
                seg, sl = (add_ocr_noise(text[s:e], lab[s:e], p, r2) if p else (text[s:e], lab[s:e]))
                _, pr = predict_spans(seg, tau); g = gold_spans(seg, sl)
                for x in pr: (tp, fp) = (tp + 1, fp) if x in g else (tp, fp + 1); per.setdefault(x[2], [0, 0, 0])[0 if x in g else 1] += 1
                for x in g - pr: fn += 1; per.setdefault(x[2], [0, 0, 0])[2] += 1
        f = lambda a, b: round(a / b, 4) if b else 0.0
        ner_metrics[f"noise={p}|tau={tau}"] = {"precision": f(tp, tp + fp), "recall": f(tp, tp + fn),
            "per_label": {k: {"precision": f(v[0], v[0] + v[1]), "recall": f(v[0], v[0] + v[2])} for k, v in per.items()}}
        print("NER", p, tau, ner_metrics[f"noise={p}|tau={tau}"]["precision"], ner_metrics[f"noise={p}|tau={tau}"]["recall"])
print("NER eval done", round(time.time() - t0))

# --- 4. Clause classifier: TF-IDF over BPE pieces + mean embedding -> logistic regression
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from scipy.sparse import hstack, csr_matrix
def clause_rows(ids, noise_p=0, cap_other=.25):
    X, Y = [], []; r2 = random.Random(3)
    for i in ids:
        text, ans = docs[i]
        for (s, e) in segment(text):
            lab = unit_label(text, s, e, ans)
            if lab == "Other" and r2.random() > cap_other: continue
            seg = text[s:e]
            if noise_p: seg, _ = add_ocr_noise(seg, [None] * len(seg), noise_p, r2)
            X.append(clause_vector_inputs(seg, tokenize(seg), emb)); Y.append(lab)
    return X, Y
Xc, Yc = clause_rows(train_i); Xn, Yn = [], []
for p in (.03, .06):
    a, b = clause_rows(train_i, p, .12); Xn += a; Yn += b
Xtr, Ytr = Xc + Xn, Yc + Yn
tf = TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True, max_features=40000, token_pattern=r"\S+")
def mat(X, fit=False): 
    T = tf.fit_transform([x[0] for x in X]) if fit else tf.transform([x[0] for x in X]); return hstack([T, csr_matrix(np.array([x[1] for x in X]) * 2)]).tocsr()
clf = LogisticRegression(C=20, max_iter=400); clf.fit(mat(Xtr, True), Ytr)
pickle.dump({"tfidf": tf, "clf": clf}, open(f"{OUT}/clause.pkl", "wb")); print("Classifier trained", len(Ytr), round(time.time() - t0))

# evaluation on held-out contracts (natural class distribution: ALL units, no downsampling), with thresholds
from sklearn.metrics import precision_recall_fscore_support
clause_metrics = {}
for p in [0, .03, .06]:
    X, Y = clause_rows(test_i, p, 1.0); P = clf.predict_proba(mat(X)); cls = clf.classes_
    for tau in [.4, .6, .7, .8]:
        pred = [cls[r.argmax()] if r.max() >= tau else "Other" for r in P]
        pr, rc, f1, sup = precision_recall_fscore_support(Y, pred, labels=[c for c in cls if c != "Other"], zero_division=0)
        m = {"per_label": {c: {"precision": round(a, 4), "recall": round(b, 4), "support": int(s)} for c, a, b, s in zip([c for c in cls if c != "Other"], pr, rc, sup)}}
        mp, mr, _, _ = precision_recall_fscore_support(Y, pred, labels=[c for c in cls if c != "Other"], average="micro", zero_division=0)
        m["micro_precision"], m["micro_recall"] = round(mp, 4), round(mr, 4); clause_metrics[f"noise={p}|tau={tau}"] = m
        print("CLS", p, tau, m["micro_precision"], m["micro_recall"])
json.dump({"ner_tau": .85, "clause_tau": .7, "labels": list(clf.classes_)}, open(f"{OUT}/config.json", "w"))
json.dump({"ner": ner_metrics, "clause": clause_metrics, "train_contracts": len(train_i), "test_contracts": len(test_i),
           "ner_note": "NER ground truth = CUAD party names + rule-based silver labels (ORG/DATE/MONEY); see README."}, open(f"{OUT}/metrics.json", "w"), indent=1)
print("DONE", round(time.time() - t0))
