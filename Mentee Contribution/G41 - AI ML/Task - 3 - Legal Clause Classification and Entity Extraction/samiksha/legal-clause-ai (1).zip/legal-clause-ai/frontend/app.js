const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const esc = s => s.replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
let last = null, uploaded = null;

$$(".tab").forEach(b => b.onclick = () => { $$(".tab").forEach(x => x.classList.toggle("active", x === b)); $$(".view").forEach(v => v.classList.toggle("active", v.id === b.dataset.tab)); if (b.dataset.tab === "metrics") loadMetrics(); });
$$(".st").forEach(b => b.onclick = () => { $$(".st").forEach(x => x.classList.toggle("active", x === b)); $$(".spane").forEach(p => p.classList.toggle("active", p.id === "s-" + b.dataset.s)); });
[["noise", "nv", v => v + "%"], ["ntau", "ev", v => (v / 100).toFixed(2)], ["ctau", "cv", v => (v / 100).toFixed(2)]].forEach(([i, o, f]) => $("#" + i).oninput = e => $("#" + o).textContent = f(e.target.value));

fetch("/api/health").then(r => r.json()).then(h => { $("#ntau").value = h.ner_tau * 100; $("#ctau").value = h.clause_tau * 100; $("#ev").textContent = h.ner_tau.toFixed(2); $("#cv").textContent = h.clause_tau.toFixed(2); $("#status").textContent = "API online"; $("#status").className = "pill ok"; }).catch(() => { $("#status").textContent = "API offline"; $("#status").className = "pill bad"; });
fetch("/api/samples").then(r => r.json()).then(list => { window.samples = list; list.forEach((s, i) => $("#sample").add(new Option(s.name, i))); });
$("#sample").onchange = e => { if (e.target.value !== "") { $("#text").value = window.samples[e.target.value].text; uploaded = null; $("#fname").textContent = ""; } };
$("#file").onchange = e => { uploaded = e.target.files[0]; if (uploaded) { $("#fname").textContent = "📄 " + uploaded.name + " (will be analysed on upload)"; $("#text").value = ""; } };

$("#go").onclick = async () => {
  const btn = $("#go"); $("#err").textContent = ""; btn.disabled = true; btn.textContent = "Analyzing…";
  const p = { ocr_noise: $("#noise").value / 100, ner_tau: $("#ntau").value / 100, clause_tau: $("#ctau").value / 100 };
  try {
    let r;
    if (uploaded && !$("#text").value.trim()) { const f = new FormData(); f.append("file", uploaded); Object.entries(p).forEach(([k, v]) => f.append(k, v)); r = await fetch("/api/analyze", { method: "POST", body: f }); }
    else r = await fetch("/api/analyze", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: $("#text").value, ...p }) });
    const j = await r.json(); if (!r.ok) throw new Error(j.error || r.statusText); last = j; render(j);
  } catch (e) { $("#err").textContent = e.message; }
  btn.disabled = false; btn.textContent = "Analyze contract";
};

function render(d) {
  $("#empty").hidden = true; $("#results").hidden = false;
  const s = d.summary;
  $("#stats").innerHTML = [["Characters", d.length.toLocaleString()], ["Risk clauses", s.clauses], ["Entities", s.entities], ["ORG", s.by_entity.ORG], ["DATE", s.by_entity.DATE], ["MONEY", s.by_entity.MONEY]].map(([a, b]) => `<div class="stat"><b>${b}</b><span>${a}</span></div>`).join("");
  $("#legend").innerHTML = '<span class="en ORG">ORG</span><span class="en DATE">DATE</span><span class="en MONEY">MONEY</span><span style="background:rgba(124,58,237,.15);color:#5b21b6">Classified clause</span>' + (d.ocr_noise_applied ? '<span style="background:#fee2e2;color:#991b1b">OCR noise simulated</span>' : "");
  // highlighted document
  const t = d.text, pts = new Set([0, t.length]); [...d.clauses, ...d.entities].forEach(x => { pts.add(x.start); pts.add(x.end); });
  const P = [...pts].sort((a, b) => a - b); let html = "";
  for (let i = 0; i < P.length - 1; i++) {
    const a = P[i], b = P[i + 1]; let seg = esc(t.slice(a, b));
    const en = d.entities.find(x => x.start <= a && x.end >= b), ci = d.clauses.findIndex(x => x.start <= a && x.end >= b);
    if (en) seg = `<span class="en ${en.label}" title="${en.label} · ${en.confidence}">${seg}</span>`;
    if (ci >= 0) seg = `<span class="cl" data-c="${ci}" title="${esc(d.clauses[ci].label)} · ${d.clauses[ci].confidence}">${seg}</span>`;
    html += seg;
  }
  $("#doc").innerHTML = html;
  // clause list
  $("#clist").innerHTML = d.clauses.length ? d.clauses.map((c, i) => `<div class="clause" data-i="${i}"><div class="h"><span class="badge">${esc(c.label)}</span><span class="conf">confidence ${(c.confidence * 100).toFixed(1)}%</span></div><div class="bar"><i style="width:${c.confidence * 100}%"></i></div><p>${esc(c.text)}</p><div class="off">span [${c.start}, ${c.end}] · alt: ${c.alternatives.slice(1).map(a => esc(a.label) + " " + (a.probability * 100).toFixed(0) + "%").join(", ")}</div></div>`).join("") : '<p class="muted">No clauses passed the confidence threshold.</p>';
  $$(".clause").forEach(el => el.onclick = () => { $$(".st")[0].click(); const c = $(`.cl[data-c="${el.dataset.i}"]`); if (c) { c.scrollIntoView({ block: "center", behavior: "smooth" }); $$(`.cl[data-c="${el.dataset.i}"]`).forEach(x => { x.classList.add("hot"); setTimeout(() => x.classList.remove("hot"), 1800); }); } });
  $("#etable").innerHTML = "<tr><th>Label</th><th>Text span</th><th>Start</th><th>End</th><th>Confidence</th></tr>" + d.entities.map(e => `<tr><td><span class="en ${e.label}">${e.label}</span></td><td>${esc(e.text)}</td><td>${e.start}</td><td>${e.end}</td><td>${e.confidence}</td></tr>`).join("");
  const out = { ocr_noise_applied: d.ocr_noise_applied, entities: d.entities, clauses: d.clauses.map(({ alternatives, ...c }) => ({ ...c, alternatives })) };
  $("#json").textContent = JSON.stringify(out, null, 2);
}
$("#copy").onclick = () => navigator.clipboard.writeText($("#json").textContent);
$("#dl").onclick = () => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([$("#json").textContent], { type: "application/json" })); a.download = "extraction.json"; a.click(); };

let M = null;
async function loadMetrics() {
  if (!M) { try { M = await (await fetch("/api/metrics")).json(); } catch { $("#mcontent").textContent = "Metrics not available — run train.py."; return; }
    const noises = [...new Set(Object.keys(M.ner).map(k => k.split("|")[0].split("=")[1]))], taus = [...new Set(Object.keys(M.ner).map(k => k.split("=")[2]))];
    $("#mnoise").innerHTML = noises.map(n => `<option value="${n}">${(n * 100)}%</option>`).join(""); $("#mtau").innerHTML = taus.map(n => `<option>${n}</option>`).join(""); $("#mtau").value = "0.8";
    $("#mnoise").onchange = $("#mtau").onchange = drawMetrics; }
  drawMetrics();
}
function drawMetrics() {
  const n = $("#mnoise").value, tau = $("#mtau").value, ner = M.ner[`noise=${n}|tau=${tau}`];
  const ck = Object.keys(M.clause).find(k => k.startsWith(`noise=${n}|`) && k.endsWith(`tau=${tau}`)) || Object.keys(M.clause).find(k => k.startsWith(`noise=${n}|`)); const cl = M.clause[ck];
  const pct = v => (v * 100).toFixed(1) + "%";
  $("#mcontent").innerHTML = `<div class="mgrid"><div class="stat"><span>NER precision</span><div class="big">${pct(ner.precision)}</div></div><div class="stat"><span>NER recall</span><div class="big">${pct(ner.recall)}</div></div><div class="stat"><span>Clause precision (micro)</span><div class="big">${cl ? pct(cl.micro_precision) : "–"}</div></div><div class="stat"><span>Clause recall (micro)</span><div class="big">${cl ? pct(cl.micro_recall) : "–"}</div></div></div>
  <h3>NER per label</h3><table><tr><th>Label</th><th>Precision</th><th>Recall</th></tr>${Object.entries(ner.per_label).map(([k, v]) => `<tr><td>${k}</td><td>${pct(v.precision)}</td><td>${pct(v.recall)}</td></tr>`).join("")}</table>
  <h3 style="margin-top:18px">Clause classes</h3>${cl ? `<table><tr><th>Class</th><th>Precision</th><th>Recall</th><th>Support</th></tr>${Object.entries(cl.per_label).map(([k, v]) => `<tr><td>${k}</td><td>${pct(v.precision)}</td><td>${pct(v.recall)}</td><td>${v.support}</td></tr>`).join("")}</table>` : ""}
  <p class="small">${M.train_contracts} training / ${M.test_contracts} held-out contracts. ${M.ner_note}</p>`;
}
