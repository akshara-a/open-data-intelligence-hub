# Decision Log — Mini Project 3: Multi-Algorithm Recommendation System Comparison

## 1. Dataset Selection

**Dataset used:** [Predict Customer Purchase Behavior Dataset](https://www.kaggle.com/datasets/rabieelkharoua/predict-customer-purchase-behavior-dataset)
**Author:** Rabie El Kharoua (Kaggle)
**File:** `customer_purchase_data.csv` — 1,500 rows, 9 columns, no missing values

**Real columns in the source file:**
`Age, Gender, AnnualIncome, NumberOfPurchases, ProductCategory, TimeSpentOnWebsite, LoyaltyProgram, DiscountsAvailed, PurchaseStatus`

**Why this dataset:** it already contains a real, cleanly labeled binary target (`PurchaseStatus`) suitable for
the classification task, plus genuine behavioral features (time on site, past purchase count, loyalty
membership, discounts used) that are meaningful inputs for both the regression and clustering tasks.

## 2. Why the schema needed transformation

The mini-project brief describes a *per-interaction* schema (`User ID, Product ID, Rating, Purchase Status,
Number of Views, Cart Status, Time Spent, Previous Purchases`). The Kaggle source is *customer-level*
(one row per customer), so several columns had to be generated or renamed to satisfy the brief. This mirrors
the same kind of schema-alignment step used in Mini Project 2 (synthetic column generation, text-to-numeric
cleaning).

| Assignment column | How it was produced | Real or engineered? |
|---|---|---|
| `UserID` | Generated sequential ID (`U00001`, `U00002`, ...) | Engineered |
| `ProductID` / `ProductCategoryName` | Derived from the real `ProductCategory` (0–4) mapped to Electronics/Clothing/Home Goods/Beauty/Sports | Real category, engineered ID |
| `PurchaseStatus` | Used exactly as provided | **Real** |
| `PreviousPurchases` | Renamed from real `NumberOfPurchases` | Real |
| `TimeSpent` | Renamed from real `TimeSpentOnWebsite` | Real |
| `CartStatus` | `1` if real `DiscountsAvailed > 0`, else `0` (proxy: a customer who redeemed a discount engaged with the cart) | Engineered proxy |
| `NumberOfViews` | `TimeSpent / 3 + PreviousPurchases * 0.5 + noise`, clipped ≥ 1 | Engineered |
| `Rating` | Weighted function of `PurchaseStatus`, `LoyaltyProgram`, `TimeSpent`, `PreviousPurchases`, plus Gaussian noise, clipped to 1–5 and rounded to 1 decimal | Engineered (no rating column exists in the source data) |

All random generation uses fixed seeds (`numpy.random.default_rng` with explicit seed values) so results are
reproducible on re-run.

## 3. Offline fallback

`generate_dataset.py` reproduces the real dataset's documented column names, dtypes, and approximate value
ranges/correlations for environments without Kaggle API access. The notebook (`Cell 2`) tries a live Kaggle
download via `kagglehub` first and only falls back to this generator on failure — so the same code path runs
identically whether or not the grading environment has internet access.

## 4. Modeling decisions

- **Ridge over plain Linear Regression** for the regression task, per the assignment's recommendation, to
  guard against overfitting across the 7 correlated input features.
- **Feature scaling (`StandardScaler`)** applied separately per task (regression / classification / clustering)
  since each uses a different feature subset.
- **`GridSearchCV`** (not `RandomizedSearchCV`) used throughout, per the assignment's recommendation for
  beginner-level explainability.
- **K chosen by silhouette score**, not just the elbow plot, since silhouette gives a single comparable number
  across k values (elbow is more subjective to read).
- Regression tuning improved R² only marginally (0.186 → 0.188) — flagged honestly in the notebook's business
  interpretation rather than presented as a bigger win than it is.
