# Mentor Evaluation Checklist — Mini Project 3

| # | Requirement | Status | Notes |
|---|---|---|---|
| 1 | Real Kaggle dataset used, with link | ✅ | `rabieelkharoua/predict-customer-purchase-behavior-dataset` |
| 2 | Regression model (Ridge) predicting rating | ✅ | MAE 0.577, RMSE 0.724, R² 0.186 |
| 3 | Classification model (Logistic Regression) predicting purchase | ✅ | Accuracy 0.840, F1 0.846 |
| 4 | Clustering model (K-Means) segmenting customers | ✅ | k=3, Silhouette 0.274 |
| 5 | GridSearchCV hyperparameter tuning for all 3 models | ✅ | See Section 8 of report |
| 6 | Elbow Method + Silhouette Score used to pick k | ✅ | k sweep 2–6, notebook Step 6 |
| 7 | All required regression metrics (MAE, RMSE, R²) | ✅ | |
| 8 | All required classification metrics (Accuracy, Precision, Recall, F1, Confusion Matrix) | ✅ | Confusion matrix plotted |
| 9 | All required clustering metrics (Inertia, Silhouette, Elbow) | ✅ | |
| 10 | Missing values / duplicates checked | ✅ | 0 missing, 0 duplicates |
| 11 | 80/20 train-test split | ✅ | Stratified for classification |
| 12 | Model comparison table included | ✅ | `outputs/model_comparison_table.csv` + report Section 9 |
| 13 | Business interpretation for each model | ✅ | Report Section 10 |
| 14 | Final conclusion / model recommendation | ✅ | Report Section 11 |
| 15 | Decision log documenting assumptions | ✅ | `Decision_Log.md` |
| 16 | Notebook runs end-to-end without errors | ✅ | Verified via `jupyter nbconvert --execute` |
| 17 | Models saved for reuse (joblib) | ✅ | `models/*.pkl` |
| 18 | README with run instructions | ✅ | `README.md` |
