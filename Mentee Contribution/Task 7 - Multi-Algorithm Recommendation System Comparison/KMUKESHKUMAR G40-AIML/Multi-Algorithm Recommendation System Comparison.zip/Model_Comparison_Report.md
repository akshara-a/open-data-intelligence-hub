# Multi-Algorithm Recommendation System Comparison Report

## 1. Project Title
Building a Recommendation System for E-Commerce — Multi-Algorithm Comparison (Regression, Classification, Clustering)

## 2. Problem Statement
An e-commerce business wants to improve its product recommendations. Three sub-problems are addressed with
three different ML approaches on the same customer base:
1. Predict the rating a user is likely to give a product (regression).
2. Predict whether a user is likely to purchase (classification).
3. Group customers into behavioral segments (clustering).

## 3. Dataset Description
**Source:** [Predict Customer Purchase Behavior Dataset](https://www.kaggle.com/datasets/rabieelkharoua/predict-customer-purchase-behavior-dataset) (Kaggle, Rabie El Kharoua)
1,500 customers, 9 original columns, no missing values, no duplicates. Real fields used directly:
`AnnualIncome, ProductCategory, TimeSpentOnWebsite, NumberOfPurchases, LoyaltyProgram, DiscountsAvailed,
PurchaseStatus`. Additional columns (`UserID`, `ProductID`, `CartStatus`, `NumberOfViews`, `Rating`) were
engineered to match the per-interaction schema the assignment calls for — full reasoning in `Decision_Log.md`.

## 4. Data Preprocessing Steps
- Verified 0 missing values and 0 duplicate rows (both before and after schema transformation).
- Mapped `ProductCategory` (0–4) to readable category names.
- Renamed `NumberOfPurchases` → `PreviousPurchases`, `TimeSpentOnWebsite` → `TimeSpent`.
- Engineered `CartStatus`, `NumberOfViews`, `Rating` (see Decision Log for formulas).
- Scaled numeric features with `StandardScaler` separately for each of the three tasks.
- 80/20 train-test split for regression and classification, stratified on `PurchaseStatus` for classification.

## 5. Regression Model — Ridge Regression
**Target:** `Rating` · **Features:** income, category, time spent, previous purchases, cart status, loyalty,
discounts availed.

| | MAE | RMSE | R² |
|---|---|---|---|
| Baseline (alpha=1.0) | 0.577 | 0.724 | 0.186 |
| Tuned (GridSearchCV, best alpha=100) | 0.577 | 0.724 | 0.186 |

Tuning `alpha` over {0.01, 0.1, 1, 10, 100} produced almost no change — the model is already close to its
ceiling given the available features. R² of ~0.19 means the model explains only a modest share of rating
variance; MAE of ~0.58 stars is still tight enough to be useful for ranking/tie-breaking between products.

## 6. Classification Model — Logistic Regression
**Target:** `PurchaseStatus` · **Features:** income, category, views, cart status, time spent, previous
purchases, rating.

| | Accuracy | Precision | Recall | F1 |
|---|---|---|---|---|
| Baseline | 0.840 | 0.815 | 0.880 | 0.846 |
| Tuned (GridSearchCV, best C=10, solver=liblinear) | 0.840 | 0.815 | 0.880 | 0.846 |

This is the strongest-performing model in the comparison. High recall (0.88) means the model catches most
actual buyers — valuable for a marketing team that would rather over-target than miss real buyers.

## 7. Clustering Model — K-Means
**Features:** views, previous purchases, rating, time spent, income, cart status.

| k | Inertia | Silhouette |
|---|---|---|
| 2 | 6432.8 | 0.250 |
| **3** | **5278.0** | **0.274** |
| 4 | 4705.9 | 0.196 |
| 5 | 4211.4 | 0.199 |
| 6 | 3855.7 | 0.206 |

k=3 gives the best silhouette score and was selected as the final model.

**Segment interpretation:**
- **Segment A — High-engagement loyal buyers:** high previous purchases, high time spent, high ratings. Best
  targets for loyalty/upsell campaigns.
- **Segment B — Window shoppers:** high views/time spent but low conversion. Best targets for retargeting ads
  or first-purchase discounts.
- **Segment C — Low-engagement occasional buyers:** low views, low spend, low purchase frequency. Lower
  marketing priority, or win-back campaigns only.

## 8. Hyperparameter Tuning Summary

| Model | Method | Grid | Best Params |
|---|---|---|---|
| Ridge | GridSearchCV (5-fold, scoring=R²) | alpha ∈ {0.01, 0.1, 1, 10, 100} | alpha=100 |
| Logistic Regression | GridSearchCV (5-fold, scoring=F1) | C ∈ {0.01,0.1,1,10}, solver ∈ {liblinear, lbfgs}, max_iter ∈ {100,200,500} | C=10, solver=liblinear, max_iter=100 |
| K-Means | Manual sweep + silhouette selection | n_clusters ∈ {2..6} | n_clusters=3 |

## 9. Evaluation Metrics — Summary

| ML Task | Algorithm | Target / Goal | Metrics Used | Best Result | Business Use |
|---|---|---|---|---|---|
| Regression | Ridge Regression | Predict product rating | MAE, RMSE, R² | R²=0.186, MAE=0.577 | Recommend highly-rated products |
| Classification | Logistic Regression | Predict purchase likelihood | Accuracy, Precision, Recall, F1 | F1=0.846, Acc=0.840 | Target likely buyers |
| Clustering | K-Means | Segment customers | Inertia, Silhouette Score | Silhouette=0.274 (k=3) | Create customer groups |

## 10. Business Interpretation
- **Classification** is the most business-ready model today: F1 of 0.846 with strong recall means the
  business can confidently flag likely buyers and act on it (targeted offers, retention campaigns).
- **Clustering** turns the same behavioral data into three actionable segments, letting marketing spend be
  allocated differently per group rather than uniformly.
- **Regression** is the weakest of the three (R²=0.186) because customer-level attributes alone don't explain
  much of rating variance — it would improve substantially with product-level signals (actual historical
  ratings, review text, product price/quality features) that this dataset doesn't include.
- **Recommended pipeline:** classification decides *who* to target, clustering decides *how* to message them,
  and regression contributes a secondary ranking signal once a shortlist of products/customers exists.

## 11. Final Conclusion
Across all three approaches, the classification model (Logistic Regression) delivered the strongest, most
directly actionable result for the stated business goals. Clustering added a useful segmentation layer on top
of the same features. The regression model, while functional and correctly tuned, is limited by the
customer-level nature of the source dataset and would need product-level features to become a strong
standalone recommender.
